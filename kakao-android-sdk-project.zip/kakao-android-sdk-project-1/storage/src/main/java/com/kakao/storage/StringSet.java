package com.kakao.storage;

/**
 * @author leoshin on 15. 9. 8.
 */
public class StringSet {
    public static final String secure_resource = "secure_resource";
    public static final String file = "file";

    public static final String origin_image = "origin_image";
    public static final String profile_image = "profile_image";
    public static final String thumbnail_image = "thumbnail_image";
}
