/**
 * SDK 내부에서 사용되는 http 통신 Api를 제공한다.
 */
package com.kakao.network;